#solution of problem-03

import numpy as np

A = np.array([[2, 4, 6], [1, 3, 5], [7, 9, 11]])
B = np.array([[8, 5, 2], [7, 4, 1], [6, 3, 0]])

sum_matrix = A + B
elementwise_product = A * B
dot_product = np.dot(A, B.T)
determinant_A = np.linalg.det(A)

print("Element-wise Sum:\n", sum_matrix)
print("\nElement-wise Product:\n", elementwise_product)
print("\nDot Product of A and B^T:\n", dot_product)
print("\nDeterminant of A:", determinant_A)

