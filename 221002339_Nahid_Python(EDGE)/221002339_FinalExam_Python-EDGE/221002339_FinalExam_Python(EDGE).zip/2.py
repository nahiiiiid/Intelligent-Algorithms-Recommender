#solution of problem-02

import pandas as pd
from google.colab import drive

drive.mount('/content/drive')

file_path = '/content/drive/My Drive/221002339_Nahid_Python(EDGE)/221002339_FinalExam_Python-EDGE/sales_large.csv'

df = pd.read_csv(file_path)

total_sales = df.groupby(['Region', 'Product'])['Sales'].sum().reset_index()

product_sales = df.groupby('Product')['Sales'].sum()
highest_selling_product = product_sales.idxmax()
highest_sales_value = product_sales.max()

print("Total Sales by Region and Product:")
print(total_sales)

print(f"\nProduct: {highest_selling_product}, Total Sales: {highest_sales_value}")
