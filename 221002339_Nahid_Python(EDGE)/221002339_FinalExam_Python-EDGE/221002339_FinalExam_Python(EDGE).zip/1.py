#solution of problem-01

import pandas as pd
from google.colab import drive

drive.mount('/content/drive')

file_path = '/content/drive/My Drive/221002339_Nahid_Python(EDGE)/221002339_FinalExam_Python-EDGE/employees_large.csv'

df = pd.read_csv(file_path)

average_salary = df.groupby('Department')['Salary'].mean().reset_index()

highest_salary_department = average_salary.loc[average_salary['Salary'].idxmax()]

print("Average Salary by Department:")
print(average_salary)

print(f"\nDepartment: {highest_salary_department['Department']}, Average Salary: {highest_salary_department['Salary']}")
