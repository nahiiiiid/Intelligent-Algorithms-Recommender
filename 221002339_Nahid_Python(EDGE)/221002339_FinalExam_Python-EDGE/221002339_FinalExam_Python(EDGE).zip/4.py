#solution of problem-04

import numpy as np

data = np.random.randn(10000) 

mean_val = np.mean(data)
median_val = np.median(data)
std_dev = np.std(data)

min_val = np.min(data)
max_val = np.max(data)

count_greater_than_mean = np.sum(data > mean_val)

normalized_data = (data - min_val) / (max_val - min_val)


print(f"Mean: {mean_val}")
print(f"Median: {median_val}")
print(f"Standard Deviation: {std_dev}\n")
print(f"Minimum Value: {min_val}")
print(f"Maximum Value: {max_val}\n")
print(f"Count of values greater than mean: {count_greater_than_mean}\n")
print(f"First 5 normalized values: {normalized_data[:5]}")
