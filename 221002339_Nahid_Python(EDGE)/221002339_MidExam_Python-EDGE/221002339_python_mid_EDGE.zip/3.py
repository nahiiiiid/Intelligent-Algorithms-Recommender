expression = input("Enter an expression: ")
result = eval(expression)

print("Result of the expression: ", result)