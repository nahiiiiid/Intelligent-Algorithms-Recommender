import math

number = int(input("Enter a number to check prime: "))

if (number > 1) and all(number % i != 0 for i in range(2, int(math.sqrt(number)) + 1)):
    print(f"The number {number} is prime!!!")
else:
    print(f"The number {number} is not prime!!!")
    
    