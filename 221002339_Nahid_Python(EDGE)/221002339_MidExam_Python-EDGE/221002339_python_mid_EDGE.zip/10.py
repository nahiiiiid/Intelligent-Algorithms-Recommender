from collections import Counter

input_file = "input.txt"
output_file = "output.txt"

with open(input_file, "r") as file:
    words = file.read().split()
    
word_count = Counter(words)

with open(output_file, "w") as file:
    for word, count in word_count.items():
        file.write(f"{word}: {count}\n")
        
print(f"Frequency have been written in {output_file}!")