list1 = set(map(int, input("Enter space-seperated numbers for list 1: ").split()))
list2 = set(map(int, input("Enter space-seperated numbers for list 2: ").split()))

print("Union", list1 | list2)
print("Intersection: ", list1 & list2)
print("Symmetric Difference: ", list1 ^ list2)
