var = input("Enter something to check it's type: ")
print("Data Type of the variable: ", type(var)) 