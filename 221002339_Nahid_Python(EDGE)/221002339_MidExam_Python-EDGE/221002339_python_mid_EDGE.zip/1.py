string = input("Enter a string: ")
print("String after reverse: ", string[::-1])