tuples = [(1, 'b'), (2, 'a'), (3, 'b'), (4, 'd')]

dictionary = dict(tuples)
sorted_dictionary = dict(sorted(dictionary.items()))

print("Original Dictionary: ", dictionary)
print("Sorted Dictionary: ", sorted_dictionary)