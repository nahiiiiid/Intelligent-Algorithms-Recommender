number1 = float(input("Enter first number: "))
number2 = float(input("Enter second number: "))

print("number1 < number2: ", number1 < number2)
print("number1 > number2: ", number1 > number2)
print("number1 == number2: ", number1 == number2)
print("number1 != number2: ", number1 != number2)
print("number1 <= number2: ", number1 <= number2)
print("number1 >= number2: ", number1 >= number2)