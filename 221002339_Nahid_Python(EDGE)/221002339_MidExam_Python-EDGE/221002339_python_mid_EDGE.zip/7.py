from statistics import mean, median, mode

numbers = list(map(int, input("Enter space-seperated number: ").split()))

print("Mean: ", mean(numbers))
print("Median: ", median(numbers))

try:
    print("Mode: ", mode(numbers))
except:
    print("Mode: No Unique Number!")