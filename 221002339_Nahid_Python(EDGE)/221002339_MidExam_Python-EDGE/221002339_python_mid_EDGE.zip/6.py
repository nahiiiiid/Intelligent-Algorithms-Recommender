import random

guess_number = random.randint(1, 100)
attempts = 5

print("Heyyy! Guess the hidden number between 1-100: ")

while (attempts > 0):
    guess = int(input("Enter a number which one you guess: "))
    
    if guess == guess_number:
        print("Congrats!!! You guessed the number right!")
        print("The right number is: ", guess_number)
        break;
    elif guess < guess_number:
        print("It's too low! Guess again: ")
    else:
        print("It's too high! Guess again: ")
    
    attempts -= 1
    
if attempts == 0:
    print("Opppsss! You can't guess the right number!")
    print("The right number is: ", guess_number)